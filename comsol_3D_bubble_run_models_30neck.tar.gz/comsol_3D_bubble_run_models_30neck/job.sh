#!/bin/bash
R0s=("10" "30" "50" "100" "500" "1000") #20
for R0 in "${R0s[@]}"; do
    cp run_basic.sh run_R0"$R0".sh
    sed -i "s/R0VALUE/$R0/" run_R0"$R0".sh
    # bash run_R0"$R0".sh
    sbatch run_R0"$R0".sh
done