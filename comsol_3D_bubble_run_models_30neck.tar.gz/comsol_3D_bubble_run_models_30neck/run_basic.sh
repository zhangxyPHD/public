#!/bin/bash 
#SBATCH -p batch        # partition name
#SBATCH --nodes=1
#SBATCH --ntasks=128
#SBATCH --mem=440G      # Memory allocation
#SBATCH -t 70:00:00    # Time limit (hh:mm:ss)
#SBATCH --job-name=bubble_R0VALUE
#SBATCH -o out-bubble_R0VALUE.txt
#SBATCH -e error-bubble_R0VALUE.txt

module load gcc/10.2.0
module load openmpi/4.1.5_gcc
module load python/3.9.1

filename="3D_bubble_R0_R0VALUE"
echo "Start $filename"
comsol batch -np 128 -inputfile ${filename}.mph -outputfile ${filename}.mph -batchlog log_${filename}
